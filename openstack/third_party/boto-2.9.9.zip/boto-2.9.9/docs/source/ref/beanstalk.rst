.. ref-beanstalk

=================
Elastic Beanstalk
=================

boto.beanstalk
--------------

.. automodule:: boto.beanstalk
   :members:
   :undoc-members:

boto.beanstalk.layer1
---------------------

.. automodule:: boto.beanstalk.layer1
   :members:
   :undoc-members:

boto.beanstalk.response
-----------------------

.. automodule:: boto.beanstalk.response
   :members:
   :undoc-members:
